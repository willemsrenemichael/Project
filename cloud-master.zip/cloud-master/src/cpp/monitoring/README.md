# Monitoring (Stackdriver Support)

This is an TensorFlow extension that exports its metrics to Stackdriver backend,
allowing users to monitor the training and inference jobs in real time.

This extension is under development at the moment.
